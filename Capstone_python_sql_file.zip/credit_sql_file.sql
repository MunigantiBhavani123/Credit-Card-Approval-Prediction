SELECT * FROM credit.credit_cleaned_csv;
select*from credit_cleaned_csv;
/*1.Group the customers based on their income type and find the average of their annual income.
select avg(Annual_income) as avg_income,Type_Income from credit_cleaned_csv
group by Type_Income
order by avg_income desc;

/*2.Find the female owners of cars and property.
select Property_Owner,Car_Owner,Gender,count(*) from credit_cleaned_csv
where Car_Owner='Y' and Property_Owner='Y'
group by Gender

/*3.Find the male customers who are staying with their families.
select Ind_ID,Family_Members,Gender from credit_cleaned_csv
where Gender='M'

/*4.Please list the top five people having the highest income.
select Ind_ID,Annual_Income as high_income from credit_cleaned_csv
order by high_income desc
limit 5;

/*5.How many married people are having bad credit?
select  Marital_status,G_B_Credit, count(*) as mary_bad_credit from credit_cleaned_csv
where Marital_status='Married' and G_B_Credit='bad'

''' Married people having total 114 bad credit cards  in that male were 51 and female were 63'''

/*6.What is the highest education level and what is the total count?
select Ind_ID,Education, count(*) as total_count from credit_cleaned_csv
where Education='Higher education' 
'''highest education level is Higher Education from that we have 426 people'''
/*7.Between married males and females, who is having more bad credit? 
select G_B_Credit,Marital_status,Gender,count(*) from credit_cleaned_csv
where G_B_Credit='bad' and Marital_status='Married'
group by Gender
'''between married male and female.Female have more bad credit_cards when compare to male'''